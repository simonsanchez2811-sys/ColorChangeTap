# Color Change Tap (Android)

Proyecto Android Studio (Java) para detectar cambios grandes en el color promedio de la pantalla y ejecutar un toque en una posición configurable.

## Qué hace
- Captura la pantalla mediante el permiso de proyección de Android.
- Calcula el color promedio de una cuadrícula de muestras repartidas por la pantalla.
- Cuando el color promedio cambia lo suficiente, espera una segunda muestra parecida y manda un único toque mediante un servicio de Accesibilidad.
- El punto de toque se define en porcentajes X/Y (50,50 = centro).
- La sensibilidad puede ajustarse entre 10 y 100.

## Limitaciones honestas
- No es una detección perfecta de todos los cambios: compara el color promedio de la pantalla. Si solo cambia una zona pequeña, el promedio podría no cambiar lo suficiente.
- Requiere habilitar el servicio de Accesibilidad y autorizar la captura de pantalla.
- Android, el dispositivo y la app objetivo afectan la latencia. La detección necesita muestras de pantalla; no puede garantizar respuesta instantánea ni 1 ms.
- Algunas apps protegidas pueden impedir la captura.
- Se entrega el código fuente, no un APK ya compilado.

## Cómo abrir
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle sincronice.
4. Ejecuta en tu Android (activa las opciones de desarrollador/depuración USB si usas cable).
5. En la app, pulsa **Activar permiso de toques** y activa Color Change Tap en Accesibilidad.
6. Vuelve a la app, configura X/Y y sensibilidad.
7. Pulsa **Iniciar detección** y autoriza la captura de pantalla.

## Uso
- X/Y 50/50 toca el centro.
- Sensibilidad menor detecta cambios más pequeños; valores demasiado bajos pueden producir falsos positivos.
- Pulsa Detener detección para parar.
