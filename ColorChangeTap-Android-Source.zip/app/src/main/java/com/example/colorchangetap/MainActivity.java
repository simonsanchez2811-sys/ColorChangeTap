package com.example.colorchangetap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 710;
    private EditText xInput, yInput, thresholdInput;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Color Change Tap");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Detecta cambios grandes en el color promedio de toda la pantalla y hace un toque por cada cambio detectado. El toque se configura en porcentaje de pantalla.");
        intro.setTextSize(16);
        root.addView(intro);

        root.addView(label("Posición del toque X (0–100 %, 50 = centro)"));
        xInput = field("50");
        root.addView(xInput);
        root.addView(label("Posición del toque Y (0–100 %, 50 = centro)"));
        yInput = field("50");
        root.addView(yInput);
        root.addView(label("Sensibilidad (10–100; menor = más sensible)"));
        thresholdInput = field("24");
        root.addView(thresholdInput);

        Button accessibility = new Button(this);
        accessibility.setText("1. Activar permiso de toques");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        Button start = new Button(this);
        start.setText("2. Iniciar detección");
        start.setOnClickListener(v -> requestCapture());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Detener detección");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, ScreenWatchService.class));
            status.setText("Detenido");
        });
        root.addView(stop);

        status = new TextView(this);
        status.setText("Estado: detenido");
        status.setTextSize(16);
        status.setPadding(0, dp(12), 0, 0);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("\nNota: Android pedirá permiso para compartir/capturar la pantalla. La detección depende de la frecuencia de captura del dispositivo; no se garantiza latencia de 1 ms. Algunas apps protegidas pueden bloquear la captura.");
        note.setTextSize(13);
        note.setPadding(0, dp(8), 0, 0);
        root.addView(note);

        setContentView(root);
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(14); t.setPadding(0, dp(10), 0, dp(2));
        return t;
    }
    private EditText field(String s) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setText(s); e.setInputType(2);
        return e;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void requestCapture() {
        if (!TapAccessibilityService.isEnabled(this)) {
            Toast.makeText(this, "Primero activá Color Change Tap en Accesibilidad.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        int x = parsePercent(xInput, 50);
        int y = parsePercent(yInput, 50);
        int threshold = Math.max(10, Math.min(100, parsePercent(thresholdInput, 24)));
        Intent intent = new Intent(this, ScreenWatchService.class);
        intent.putExtra("tap_x", x / 100f);
        intent.putExtra("tap_y", y / 100f);
        intent.putExtra("threshold", threshold);
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }
    private int parsePercent(EditText e, int fallback) {
        try { return Math.max(0, Math.min(100, Integer.parseInt(e.getText().toString().trim()))); }
        catch (Exception ex) { return fallback; }
    }
    private float pendingX, pendingY;
    private int pendingThreshold = 24;

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Permiso de captura cancelado.", Toast.LENGTH_SHORT).show();
            return;
        }
        pendingX = parsePercent(xInput, 50) / 100f;
        pendingY = parsePercent(yInput, 50) / 100f;
        pendingThreshold = Math.max(10, Math.min(100, parsePercent(thresholdInput, 24)));
        Intent service = new Intent(this, ScreenWatchService.class);
        service.putExtra("result_code", resultCode);
        service.putExtra("projection_data", data);
        service.putExtra("tap_x", pendingX);
        service.putExtra("tap_y", pendingY);
        service.putExtra("threshold", pendingThreshold);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        status.setText("Estado: detectando cambios…");
    }
}
