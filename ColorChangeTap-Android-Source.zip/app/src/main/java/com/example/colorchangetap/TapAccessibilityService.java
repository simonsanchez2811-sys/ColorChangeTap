package com.example.colorchangetap;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.content.Context;
import android.view.accessibility.AccessibilityEvent;

public class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService instance;
    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    public static boolean isEnabled(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        return enabled.toLowerCase().contains(context.getPackageName().toLowerCase() + "/");
    }
    public static void tap(float xFraction, float yFraction) {
        TapAccessibilityService s = instance;
        if (s == null) return;
        int w = s.getResources().getDisplayMetrics().widthPixels;
        int h = s.getResources().getDisplayMetrics().heightPixels;
        float x = Math.max(0, Math.min(w - 1, xFraction * w));
        float y = Math.max(0, Math.min(h - 1, yFraction * h));
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 1);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        s.dispatchGesture(gesture, null, null);
    }
}
