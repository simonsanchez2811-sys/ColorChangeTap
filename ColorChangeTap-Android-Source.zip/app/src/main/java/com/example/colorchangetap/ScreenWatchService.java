package com.example.colorchangetap;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;

public class ScreenWatchService extends Service {
    private static final String CHANNEL = "color_change_tap";
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread thread;
    private Handler handler;
    private float tapX = 0.5f, tapY = 0.5f;
    private int threshold = 24;
    private boolean hasBaseline = false;
    private double lastR, lastG, lastB;
    private long lastTapMs = 0;
    private int consecutiveChanged = 0;
    private double pendingR, pendingG, pendingB;
    private int pendingCount = 0;
    private int width, height, density;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !intent.hasExtra("projection_data")) {
            stopSelf(); return START_NOT_STICKY;
        }
        tapX = intent.getFloatExtra("tap_x", 0.5f);
        tapY = intent.getFloatExtra("tap_y", 0.5f);
        threshold = intent.getIntExtra("threshold", 24);
        startForeground(1001, buildNotification());
        int resultCode = intent.getIntExtra("result_code", 0);
        Intent data = intent.getParcelableExtra("projection_data");
        MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mgr.getMediaProjection(resultCode, data);
        if (projection == null) { stopSelf(); return START_NOT_STICKY; }
        startCapture();
        return START_NOT_STICKY;
    }

    private void startCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.Display display = wm.getDefaultDisplay();
            display.getRealMetrics(dm);
        } else {
            wm.getDefaultDisplay().getRealMetrics(dm);
        }
        width = dm.widthPixels; height = dm.heightPixels; density = dm.densityDpi;
        thread = new HandlerThread("ColorSampler");
        thread.start();
        handler = new Handler(thread.getLooper());
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image != null) analyze(image);
            } catch (Exception ignored) {
            } finally {
                if (image != null) image.close();
            }
        }, handler);
        virtualDisplay = projection.createVirtualDisplay("ColorChangeTap",
            width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(), null, handler);
    }

    private void analyze(Image image) {
        Image.Plane plane = image.getPlanes()[0];
        java.nio.ByteBuffer buffer = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int stepX = Math.max(1, width / 64);
        int stepY = Math.max(1, height / 64);
        long sr = 0, sg = 0, sb = 0, n = 0;
        for (int y = height / 20; y < height - height / 20; y += stepY) {
            for (int x = 0; x < width; x += stepX) {
                int index = y * rowStride + x * pixelStride;
                if (index + 2 >= buffer.limit()) continue;
                int r = buffer.get(index) & 0xff;
                int g = buffer.get(index + 1) & 0xff;
                int b = buffer.get(index + 2) & 0xff;
                sr += r; sg += g; sb += b; n++;
            }
        }
        if (n == 0) return;
        double r = (double)sr / n, g = (double)sg / n, b = (double)sb / n;
        if (!hasBaseline) {
            lastR = r; lastG = g; lastB = b; hasBaseline = true; return;
        }
        double delta = (Math.abs(r-lastR) + Math.abs(g-lastG) + Math.abs(b-lastB)) / 3.0;
        if (delta >= threshold) {
            long now = android.os.SystemClock.elapsedRealtime();
            // Require two similar changed frames before firing to reduce one-frame noise.
            double pd = (Math.abs(r-pendingR) + Math.abs(g-pendingG) + Math.abs(b-pendingB)) / 3.0;
            if (pendingCount > 0 && pd < 10) pendingCount++; else {
                pendingR = r; pendingG = g; pendingB = b; pendingCount = 1;
            }
            if (pendingCount >= 2 && now - lastTapMs >= 80) {
                TapAccessibilityService.tap(tapX, tapY);
                lastTapMs = now;
                lastR = r; lastG = g; lastB = b;
                pendingCount = 0;
            }
        } else {
            // Keep baseline stable; minor changes are treated as noise.
            pendingCount = 0;
            // Slowly follow gradual scene drift so a gradual change doesn't eventually trigger.
            lastR = lastR * 0.995 + r * 0.005;
            lastG = lastG * 0.995 + g * 0.005;
            lastB = lastB * 0.995 + b * 0.005;
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Color Change Tap", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Color Change Tap activo")
                .setContentText("Detectando cambios de color en la pantalla")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
        }
        return new Notification.Builder(this)
            .setContentTitle("Color Change Tap activo")
            .setContentText("Detectando cambios de color")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build();
    }

    @Override public void onDestroy() {
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (projection != null) projection.stop();
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
